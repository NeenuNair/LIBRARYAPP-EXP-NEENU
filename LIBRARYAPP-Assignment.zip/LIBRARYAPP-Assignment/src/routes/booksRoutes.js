const express = require('express');
const booksRouter = express.Router();
function router(nav,navBooks){


    
    booksRouter.get('/',function(req,res){
        res.render("books",{
            nav,
            navBooks,
            title: 'WELCOME TO DIGITAL LIBRARY'
        });
    });
    

return booksRouter;

}

module.exports = router;  