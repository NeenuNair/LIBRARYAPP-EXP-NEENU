const express = require('express');
const contactRouter = express.Router();
function router(nav,navSign){


    
    contactRouter.get('/',function(req,res){
        res.render("contact",{
            nav,
            navSign,
            title: 'WELCOME TO DIGITAL LIBRARY'
        });
    });
    

return contactRouter;

}

module.exports = router;  